En este apartado se localiza el código utilizado en el proyecto. En el siguiente enlace se podrán localizar tanto los notebooks en Python como el código de las técnicas de webscraping que se intentaron aplicar para la obtención de los conjuntos de datos.
https://github.com/joseagrau/TFM-BigDataDataScience
En el cuaderno TFM.ipnyb se localiza el código para la aplicación de las técnicas de limpieza de datos, gestión de outliers, selección de datos, normalizado de datos, matriz de correlación, PCAs y clustering aglomerativo jerárquico.


En el cuaderno TFMSalePriceMenos1M.ipnyb se muestra el apartado de modelado, donde se han utilizado los distintos algoritmos utilizando un conjunto de datos limpio.


Por último, en el cuaderno Arbol grafico.ipynb se muestra el árbol de decisión utilizado en el proyecto gráficamente para poder interpretar fácilmente el camino que sigue el árbol para tomar decisiones.  